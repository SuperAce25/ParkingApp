<template>
  <div id="contenido">
    <h1>Balance Mensual</h1>
    <form>
      <label for="Fecha">Fecha</label><br />
      <input type="date" id="Año" name="Año" required /><br>
      <input type="submit" value="Generar" />
    </form>
    <table>
      <tr>
        <th>Propietario</th>
        <th>Placa</th>
        <th colspan="2">Valor</th>
      </tr>
      <tr>
        <td>John Doe</td>
        <td>BEX54C</td>
        <td>$124.000</td>
      </tr>
    </table>
  </div>
</template>

<script>
export default {};
</script>

<style>
#contenido {
  width: 97%;
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
  align-self: center;
}
table{
    position:fixed;
    border: 1px solid black;
}
</style>