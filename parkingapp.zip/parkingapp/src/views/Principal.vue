<template>
  <div id="principal">
    <div id="contenido">
      <h4>¿Qué es ParkingApp?</h4>
      <p>
        Es la mejor opción para la gestión de parqueaderos; ParkingApp le
        permite realizar sus funciones cotidianas como el Registro de clientes,
        ingresos y salidas de vehículos, además de generar facturas y balances,
        todo al alcance de un click
      </p>
    </div>
    <br />
    <div id="contenido">
      <h4>¿Para quien está desarrollado ParkingApp?</h4>
      <p>
        Tanto empleados como administradores de parquederos pueden aprovechar
        las ventajas del desarrollo cómodo y simple que brinda ParkingApp, y los
        clientes se sentirán a gusto al contar con una atención más eficiente.
        ¡Todo lo hacemos para que tu negocio crezca!
      </p>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style>
#contenido {
  width: 97%;
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
  align-self: center;
}
#principal {
  width: 80%;
  align-items: center;
}
</style>