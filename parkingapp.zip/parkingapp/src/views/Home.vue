<template>
  <!-- <Login/> -->
  <Principal/>
</template>

<script>
// @ is an alias to /src
// import Login from './Login.vue'
import Principal from './Principal.vue'

export default {
  name: 'Home',
  components: {
    Principal
  }
}
</script>
