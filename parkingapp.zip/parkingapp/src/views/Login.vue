<template>
    <aside>
        <form action="#" class="formulario">
            <label for="user">Usuario</label>
            <input type="text" placeholder="Usuario" /><br />
            <label for="user">Password</label>
            <input type="password" placeholder="Usuario" /><br />
            <button type="submit">Ingresar</button>
        </form>
    </aside>
</template>
<script>
export default ({
    
})
</script>

<style>
aside{
    padding: auto;
    width: 350px;
    min-height: 80vh;
    width: 30%;
    background-color: rgb(230, 221, 221);
}
aside .formulario{
    padding: 20px;
    margin-left: 23px;
    display: flex;
    flex-direction: column;
}
aside .formulario input{
    padding: 12px;
    margin-top: 12px;
    background: #fff;
}
aside .formulario a{
    padding: 6px 27px 7px 26px;
    text-decoration: none;
    font-size: .75em;
    font-weight: bold;
    color: #556;
    border-style: solid;
    border-width: 1px;
    border-color: #bfbfbf #139511 #139511 #bfbfbf;
    background: #139511 #139511 #bfbfbf;
}
</style>