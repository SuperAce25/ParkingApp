<template>
  <div id="contenido">
    <h1>Registrar Clientes</h1>
    <form action="/action_page.php">
      <label for="TipIde">Tipo de Identificación</label>
      <select id="TipoIde" name="TipoIde" required>
        <option value="CC">Cedula de Ciudadania</option>
        <option value="CE">Cedula de Extranjería</option>
        <option value="PE">Permiso Especial de Permanencia</option>
        <option value="PA">Pasaporte</option>
      </select>

      <label for="IdCliente">Numero de Identificación</label>
      <input
        type="text"
        id="IdCliente"
        name="IdCliente"
        placeholder="Numero de Identificación del Usuario"
        required
      />

      <label for="Nombre">Nombre</label>
      <input
        type="text"
        id="Nombre"
        name="Nombre"
        placeholder="Nombre del Cliente"
        required
      />

      <label for="Telefono">Teléfono</label>
      <input
        type="text"
        id="Telefono"
        name="Telefono"
        placeholder="Numero Telefónico"
        required
      />

      <label for="Direccion">Dirección</label>
      <input
        type="text"
        id="Direccion"
        name="Direccion"
        placeholder="Dirección"
        required
      />

      <label for="Email">Correo Electrónico</label>
      <input type="text" id="Email" name="Email" placeholder="Email" required />

      <input type="submit" value="Submit" />
    </form>
  </div>
</template>
<style>
input[type=text], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 80%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}
#contenido {
    width: 50%;
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
    align-self: center;
}
</style>