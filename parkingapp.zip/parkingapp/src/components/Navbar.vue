<template>
  <ul>
    <li><a class="active" href="/">Inicio</a></li>
    <li><a href="/registrocliente">Registro Clientes</a></li>
    <li><a href="/registroentrada">Registrar Ingreso</a></li>
    <li><a href="Registro_Salida.html">Registrar Salida</a></li>
    <li><a href="balance">Balance Mensual</a></li>
    <li><a href="Descargar_Recibo.html">Descargar Recibo</a></li>
    <li><a href="Registro_Empleado.html">Registrar Empleados</a></li>
    <li><a href="Reporte_Clientes.html">Reporte Clientes</a></li>
  </ul>
</template>

<script>
export default ({
    
})
</script>

<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}
</style>