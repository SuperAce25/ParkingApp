<template>
    <div id="cabecera">
        <img src="../assets/Imagenes/P.jpg" heigth="120" width="120" alt="Mi Parking"/>
        <h1>Parking-App</h1>
    </div>
</template>

<script>
export default({

})
</script>

<style>
    #cabecera{
    width: 97%;
    background-color: #284fbb;
    padding: 20px;
    }
    img{
        height: 200px;
        width: 300px;
    }
</style>